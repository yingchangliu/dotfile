
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "sss.h"
#include "tt.h"
#include "dfm.h"
#include "hdr.h"
#include "amf.h"
#include "bool.h"

#include "wild.h"
#include "bot.h"
#include "ucf.h"
#include "exm.h"
#include "msg.h"
#include "clf.h"
#include "bbs.h"
#include "cpf.h"
#include "co.h"
#include "dff.h"

#include "defs.h"
#include "string_utils.h"

#include "octopus.h"

#define	MBLKSZ	500
#define	MENTRY	40

DFM_EXTERN
TT_EXTERN
SSS_EXTERN

extern float *tty[MXTT];
extern float *ttx[MXTT];

typedef struct {
    char name[64];
    double t;
} ttdata;

ttdata *
ttdata_new(char *name, double tt) {
    ttdata *t = calloc(1, sizeof(ttdata));
    strlcpy(t->name, name, 64);
    t->t = tt;
    return t;
}

int
ttdata_compare(const void *pa, const void *pb) {
    ttdata *a = *(ttdata **) pa;
    ttdata *b = *(ttdata **) pb;
    if(a->t < b->t) { return -1; }
    if(a->t > b->t) { return  1; }
    return 0;
}

int
phases_contains_all() {
    for(int i = 0; i < cmtt.nphases; i++) {
        if(strcasecmp(kmtt.kphases[i], "all") == 0) {
            return 1;
        }
    }
    return 0;
}

int
phase_is_set(char *phase, char picks_set[][128], int nset) {
    int j = 0;
    for(j = 0; j < nset; j++) {
        if(strcmp(phase, picks_set[j]) == 0) {
            return TRUE;
        }
    }
    return FALSE;
}
int
phase_set(char *phase, char picks_set[][128], int nset) {
    strcpy(picks_set[nset], phase);
    nset += 1;
    return nset;
}


static void
sac_truncate(char *s) {
    int i = 0;
    int m = 0;
    int n = 0;
    char tmp[8] = {0};
    char *p;
    if (!s) {
        return;
    }
    p = strchr(s, ' ');
    if (p) {
        *p = 0;
    }
    m = strlen(s);
    p = s;
    i = 0;
    while(s[i]) {
        if(s[i] < 0) {
            switch(s[i] & 0xF0) {
            case 0xF0: n = 4; break;
            case 0xE0: n = 3; break;
            default:   n = 2; break;
            }
            memset(tmp, 0, sizeof tmp);
            memcpy(tmp, s+i, n);
            fprintf(stdout, "Removing non-ascii character %-4s [0x", tmp);
            for(int k = 0; k < n; k++) {
                fprintf(stdout, "%02hhx", tmp[k] & 0xFF);
            }
            fprintf(stdout, "]\n");
            memmove(s+i, s + i + n, m-i-n);
            s[m-n] = 0;
        } else {
            i++;
        }
    }
}

int
parse_traveltime(char *line, char *name, size_t n, double *tt) {
    int k = 0;
    int set = 0;
    char *endptr = NULL;
    char *field = NULL;
    *tt = 0.0;
    memset(name,0,n);
    while((field = strsep(&line, " ")) != NULL) {
        if(strlen(field) > 0) {
            if(k == 2) { // Phase name
                strlcpy(name, field, n);
                set++;
            } else if(k == 3) { // Traveltime
                *tt = strtod(field, &endptr);
                if(endptr == NULL || strlen(endptr) == 0) {
                    set++;
                }
            }
            k++;
            if(set == 2) {
                return 1;
            }
        }
    }
    return 0;
}

static int
set_traveltime(sac *s, int k, char *name, double tt, int lpicks, int verbose, int onrecord) {
    double time = 0.0;
    if (O(s) != SAC_FLOAT_UNDEFINED) {
        time = (double) O(s) + tt;
    } else {
        time = tt;
    }
    if(onrecord && (time < B(s) || time > E(s))) {
        return k;
    }
    if (verbose && !lpicks) {
        fprintf(stdout, "traveltime: %-8s at %.4f s [ t = %.4f s ]\n", name, (float) time, (float) tt);
    }
    if (lpicks && k < 10) {
        sac_set_float(s, k + SAC_T0, time);
        sac_set_string(s, k + SAC_KT0, name);
        if (verbose) {
            fprintf(stdout, "traveltime: setting phase %-8s at %.4f s [ t = %.4f s ] t%d\n", name, (float) time, (float) tt, k);
        }
        if(strlen(name) > 8) {
            printf("traveltime:         phase %s truncated in kt%d\n", name, k);
        }
        k++;
    }
    if(lpicks && k >= 10 && verbose) {
        printf("traveltime: error setting phase %-8s to %f, too many phases \n", name, tt);
    }
    return k;
}

char *
string_join(char vals[60][128], int nvals, char *dst, size_t n, char *join) {
    memset(dst, 0, n);
    for(int i = 0; i < nvals; i++) {
        strlcat(dst, vals[i], n);
        if(i < nvals-1) {
            strlcat(dst, join, n);
        }
    }
    return dst;
}

void
xtraveltime(int *nerr) {
    char kalpha[21], kcard[MCMSG + 1], kcont[9], kdflin[MCMSG + 1], kform[9];
    int lbcksp, lexpnd, lfree, lmore, ltoend;
    int idx, ic, ic1, ic2, iopch[MXTT], itype, jdx, jch, jdfl, jen, nblksz,
        nblksz2, nc, ncerr, nchar, ndcont, ndflin, ndform, nentry, nhlines,
        nmodel, nPickStart = 0, nttmsv, numch, numxch, numych, numsave;
    FILE *nun = NULL;
    float fentry[MENTRY];
    char kValue[21];

    string_list *list, *files;
    char *file;
    float *tx;
    int i;
    sac *s;
    static int nphaseNames = 0; /* for use with TAUP options only */

    int lmodel = FALSE,         /* was global, now it's local.  maf 960829 */
        ltaup = FALSE;          /* TRUE if input file was produced by taup_curve. */
    int online = FALSE;
    /* variables added to put traveltime into a blackboard variable. maf 970512 */
    int fileNumber;
    int lbb = FALSE;
    char bbName[33];

    float *const Fentry = &fentry[0] - 1;
    int *const Iopch = &iopch[0] - 1;
    double tmp;
    char verbose_quiet[2][9] = {"verbose ", "quiet   "};
    int phase_repeat;
    int nverbose = 0;
    static int verbose = TRUE;
    //static int quiet = FALSE;
    static float depth_units = 1.0;     /* Assume *evdp is in kilometers */
    static float ttscale = 1.0;
    static int lphase = FALSE;
    static int lpicks = FALSE;
    static int iphase = 0;
    static int onrecord = FALSE;
    file = NULL;
    cmtt.ttdep = 0.0;
    tx = NULL;
    list = NULL;
    s = NULL;
    int all_requested = FALSE;
        /*=====================================================================
	 * PURPOSE:  To read in travel time curves from a file.
	 *=====================================================================
	 * INPUT ARGUMENTS:
	 *=====================================================================
	 * OUTPUT ARGUMENTS:
	 *    NERR:    Error flag. Set to 0 if no error occurred.
	 *             Potential error numbers: 
	 *=====================================================================
	 * MODULE/LEVEL: SSS/2
	 *=====================================================================
	 * GLOBAL INPUT:
	 *    MACH:
	 *=====================================================================
	 * GLOBAL OUTPUT:
	 *=====================================================================
	 * SUBROUTINES CALLED:
	 *=====================================================================
	 * LOCAL VARIABLES:
	 *    NSNDFL:  Save count of files in working storage [i].
	 *=====================================================================
	 * MODIFICATION HISTORY:
	 *    970808:  Globalized nhlines to keep it consistant.
	 *             Update the way the X data is allocated and filled. maf
	 *    970514:  Add bb option to allow one traveltime for one phase for
	 *             one waveform to be stored in a blackboard variable. maf
         *    970129:  Add parameter (1) to cnvfre.  1 means that if a string
         *             of digits is too long, warn user & end command.  maf 
	 *    960829:  Made iasp91 the default model for traveltime.  
	 *             Code also added to allow succeeding calls to 
	 *             traveltime to use current settings as default.
	 *             Also set default units: degrees for model and
	 *             kilometers for files.  The user can change
	 *             the units at the command line.
	 *    920722:  Original version.
	 *=====================================================================
	 * DOCUMENTED/REVIEWED:
	 *===================================================================== */
    /* PROCEDURE: */
    *nerr = 0;

    /* initialize */
    ndflin = 0;                 /* added.  maf 960829 */
    /* initialize bbName. maf 970514 */
    memset(bbName, 0, sizeof(bbName));

    for (idx = 0; idx < 8; idx++)
        kform[idx] = ' ';
    kform[8] = '\0';

    /* PARSING PHASE: */

    lmore = FALSE;
    nttmsv = 0;

    cmtt.ittunit = TTDEGREE;

    /* - Loop on each token in command: */

    while (lcmore(nerr)) {

        /* -- "MORE":  signifies addition of more files to current travel time curves
         *             rather than replacement of current list with new one. */
        if (lckey("&MORE$", 7)) {
            lmore = TRUE;
            nttmsv = cmtt.nttm;
        }

        /* -- "DIR CURRENT|name":  set the name of the default subdirectory. */
        else if (lkchar("DIR#$", 6, MCPFN, kmdfm.krddir, MCPFN + 1, &nchar)) {
            if (memcmp(kmdfm.krddir, "CURRENT", 7) == 0 ||
                memcmp(kmdfm.krddir, "current", 7) == 0) {
                fstrncpy(kmdfm.krddir, MCPFN, " ", 1);
            } else if (kmdfm.krddir[nchar - 1] != KDIRDL) {
                char dirDelimterString[2];
                dirDelimterString[0] = KDIRDL;
                dirDelimterString[1] = '\0';
                subscpy(kmdfm.krddir, nchar, -1, MCPFN, dirDelimterString);
            }
        }

        /* -- "UNITS degrees/kilometers":  select units of travel time curves */
        /*
           else if( lklist( "UNITS$",7, (char*)kmsss.kdwun,9, MDWUN, &cmtt.ittunit ) ){
           lunitsSet = TRUE ; 
           }
         */
        else if (lckeyExact("M$", 3)) {
            depth_units = 1000.0;
        } else if (lckeyExact("KM$", 4)) {
            depth_units = 1.0;
        }
        /* -- "DEPTH depth": Depth at which to produce curves */
        else if (lkreal("DEPTH$", 7, &tmp)) {
            cmtt.ttdep = (float) tmp;
        }

        else if (lclist((char *) verbose_quiet, 9, 2, &nverbose)) {
            verbose = (nverbose == 1);
        }
        /*else if (lckey("V#ERBOSE$", 10)) {
            verbose = TRUE;
            quiet = FALSE;
        } else if (lckey("Q#UIET$", 8)) {
            quiet = TRUE;
            verbose = FALSE;
            }*/
        /* -- "HEADER count": set number of lines to skip. */
        else if (lkint("HEADER$", 8, &nhlines)) {
            cmtt.nhlines = nhlines;     /* update global.  maf 970808 */
        }

        /* -- "CONTENT string": set default wave. */
        else if (lkchar
                 ("&CONTENT$", 10, MCMSG, kmdfm.kdcont, MCMSG + 1, &ndcont)) {
            modcase(TRUE, kmdfm.kdcont, ndcont, kmdfm.kdcont);
        }

        /* -- "MODEL string": set default model. */
        else if (lkchar("&MODEL$", 8, MCPW, kmtt.kmodel, 9, &nmodel)) {
            lmodel = TRUE;      /* maf 960829 */
        }

        /* -- "FREE":  use free-field rather than formatted input. */
        else if (lckey("&FREE$", 7)) {
            cmdfm.ldfree = TRUE;
        }

        /* -- "BB": put traveltime of first phase in list for the 
           specified waveform into the specified blackboard 
           variable.  maf 970514 */
        else if (lkint("BB$", 4, &fileNumber)) {
            if (lcchar(bbName, sizeof(bbName))) {
                lbb = TRUE;
            } else {
                setmsg("WARNING", 5123);
                outmsg();
                clrmsg();
                lbb = FALSE;
            }
        }

        else if (lklogi("PIC#KS$", 8, &lpicks, &nPickStart)) {
        }
        else if (lklog("#ONRECORD$", 11, &onrecord)) { }

        /* -- "PHASE":  the rest are phases */
        else if (lckey("PHASE#S$", 10)) {
            lphase = TRUE;
        }

        /* -- "TAUP":  read a file produced by taup_curve. */
        else if (lckey("&TAUP$", 8)) {
            ltaup = TRUE;
        }
        else if (lckey("online$", -1)) {
            online = TRUE;
        }


        /* -- "FORMAT string": use formatted input and set default format. */
        else if (lkchar("&FORMAT$", 9, MCMSG, kmdfm.kdform, MCMSG + 1, &ndform)) {
            cmdfm.ldfree = FALSE;
            modcase(TRUE, kmdfm.kdform, ndform, kmdfm.kdform);
        }

        else if (lckey("&CLEAR$", 8)) {
            all_requested = FALSE;
            iphase = 0;
        }

        /* -- "phaselist": add a phase to the list */
        else if (lphase) {
            if (lcchar
                ((char *) kmtt.kphases[iphase], sizeof(kmtt.kphases[iphase]))) {
                phase_repeat = FALSE;
                for (i = 0; i < iphase; i++) {
                    if (strcmp(kmtt.kphases[iphase], kmtt.kphases[i]) == 0) {
                        phase_repeat = TRUE;
                    }
                }
                if (phase_repeat == FALSE) {
                    iphase = iphase + 1;
                }
            }
        }

        /* -- "filelist":  define a new filelist (or add to old filelist). */
        else if ((list = lcdfl())) {
            if (lmodel) {
                /* we have a model and a file.  today we aren't set up to do
                   both.  Display a message to that effect, and get on with
                   the model. everything within the else if is from maf 960829 */
                setmsg("WARNING", 5120);
                outmsg();
            }                   /* end if ( lmodel ) */
        }

        /* -- Bad syntax. */
        else {
            cfmt("ILLEGAL OPTION:", 17);
            cresp();
        }

    }                           /* end while ( lcmore( nerr ) ) */

    /* - The above loop is over when one of two conditions has been met:
     *   (1) An error in parsing has occurred.  In this case NERR is > 0 .
     *   (2) All the tokens in the command have been successfully parsed. */

    if (*nerr != 0)
        goto L_8888;

    /* Set default model to iaspmodel. */
    if (lmodel == FALSE && ndflin <= 0) {
        if (cmtt.lpreviousModel)
            /* use same model used last time. */
            lmodel = TRUE;
        else if (cmtt.previousFileNames != NULL && lphase == FALSE) {
            /* use same file(s) used last time */
            strncpy(kdflin, cmtt.previousFileNames, MCMSG);
            ndflin = cmtt.npreviousFileNames;
        } else {
            lmodel = TRUE;
            strcpy(kmtt.kmodel, "iasp91  ");
        }
    }

    /* end if ( lmodel == FALSE && ndflin <= 0 ) */
    /* Disallow concurrent TAUP and MODEL options. */
    if (ltaup && lmodel) {
        *nerr = 5124;
        goto L_8888;
    }
    if(ltaup && online) {
        *nerr = 5124;
        goto L_8888;
    }

    /* Next 20 lines allow next call to traveltime to default to current settings. maf 960829 */
    cmtt.lpreviousModel = lmodel;

    cmtt.npreviousFileNames = 0;
    if (cmtt.previousFileNames != NULL) {
        free(cmtt.previousFileNames);
        cmtt.previousFileNames = NULL;
    }

    if (!lmodel) {
        /* Allocate space for .previousFileNames */
        cmtt.previousFileNames =
            (char *) malloc((sizeof(kdflin) < MCMSG ? sizeof(kdflin) : MCMSG) +
                            1);
        if (cmtt.previousFileNames == NULL) {
            *nerr = 301;
            setmsg("ERROR", *nerr);
            outmsg();
            goto L_8888;
        }
        strncpy(cmtt.previousFileNames, kdflin, MCMSG);
        cmtt.npreviousFileNames = ndflin;
    }

    /* set default phases if no phases selected */
    if (lmodel && iphase == 0 && online == FALSE) {
        char phases[1024] = {0}, *ptmp = NULL, *token = NULL, *brkt = NULL;
        char sep[3] = " ,";
        lphase = TRUE;
        if((ptmp = getenv("SAC_TRAVELTIME_PHASES"))) {
            strlcpy(phases, ptmp, sizeof phases);
        } else {
            strlcpy(phases, "P S Pn Pg Sn Sg", sizeof phases);
        }
        token = strtok_r(phases, sep, &brkt);
        while(token) {
            strlcpy(kmtt.kphases[iphase], token, PHASE_NAME_LENGTH-1);
            iphase += 1;
            token = strtok_r(NULL, sep, &brkt);
        }
    }
    if (iphase != 0)
        cmtt.nphases = iphase;

    if (cmtt.ttdep == 0.0 && saclen() > 0) {
        if (!(s = sacget(0, FALSE, nerr))) {
            goto L_9000;
        }
        //getfil( 1, FALSE, &n1, &n1, &n1, nerr );
        cmtt.ttdep = s->h->evdp;
    }
    for (i = 0; i < cmtt.nphases; i++) {
        sac_truncate(kmtt.kphases[i]);
    }

    if (verbose) {
        fprintf(stdout, "traveltime: depth: %.3f km\n", cmtt.ttdep / depth_units);
    }

    /* EXECUTION PHASE: */

    /* - Convert KDFLIN which may contain wild-cards, predefined file sets, etc.
     *   into an expanded file list.  Echo expanded file list if requested. */

    /* - Release memory associated with old travel time curves */

    if (cmtt.nttm != nttmsv) {
        for (idx = 1; idx <= cmtt.nttm; idx++) {
            FREE(ttx[idx]);
            FREE(tty[idx]);
        }                       /* end for */
    }

    /* end if */
    /* - Release old TAUP phase names. */
    if (kmtt.kphaseNames) {
        for (idx = 0; idx < nphaseNames; idx++) {
            if (kmtt.kphaseNames[idx])
                free(kmtt.kphaseNames[idx]);
        }
        free(kmtt.kphaseNames);
        kmtt.kphaseNames = NULL;
        nphaseNames = 0;
    }

    /* - Set the current file count for using read or read-more. */

    if(online) {
        char name[64] = {0};
        char ophases[2048] = {0};
        char model[32] = {0};
        double tt = 0.0;
        strlcpy(model, kmtt.kmodel, sizeof(model));
        rstrip(model);
        for (jdfl = 1; jdfl <= saclen(); jdfl++) {
            if (!(s = sacget(jdfl - 1, FALSE, nerr))) {
                goto L_9000;
            }
            request *tr = request_new();
            request_set_url(tr, "http://service.iris.edu/irisws/traveltime/1/query?");
            request_set_arg(tr, "evdepth", arg_double_new(s->h->evdp));
            request_set_arg(tr, "distdeg", arg_double_new(s->h->gcarc));
            request_set_arg(tr, "mintimeonly", arg_string_new("true"));
            request_set_arg(tr, "noheader", arg_string_new("true"));
            request_set_arg(tr, "model", arg_string_new(model));
            if(phases_contains_all()) {
                request_set_arg(tr, "phases", arg_string_new("ttall"));
            } else if(iphase > 0) {
                string_join(kmtt.kphases, iphase, ophases, sizeof(ophases), ",");
                request_set_arg(tr, "phases", arg_string_new(ophases));
            }
            //request_set_verbose(tr, 1);
            result *r = request_get(tr);
            if(!result_is_ok(r)) {
                if(result_http_code(r) == 204) {
                    printf("Error: Phase not found: %s\n", ophases);
                } else if(result_code(r) == 0 && result_http_code(r) == 500) {
                    printf("Error: Server Error for phase: %s\n", ophases);
                } else {
                    printf("Error: %s\n", result_error_msg(r));
                }
            } else {
                int sort = phases_contains_all();
                char *data = result_data(r);
                char *line = NULL;
                ttdata **ttd = NULL;
                ttd = (ttdata **) xarray_new('p');
                int k = 0;
                while((line = strsep(&data, "\n")) != NULL) {
                    if(parse_traveltime(line, name, sizeof(name), &tt)) {
                        if(sort) {
                            ttd = xarray_append(ttd, ttdata_new(name, tt));
                        } else {
                            k = set_traveltime(s, k, name, tt, lpicks, verbose, onrecord);
                        }
                    }
                }
                if(sort) {
                    qsort(ttd, xarray_length(ttd), sizeof(void *), ttdata_compare);
                    for(size_t i = 0; i < xarray_length(ttd); i++) {
                        k = set_traveltime(s, k, ttd[i]->name, ttd[i]->t, lpicks, verbose, onrecord);
                    }
                    xarray_free_items(ttd, free);
                    xarray_free(ttd);
                    ttd = NULL;
                }
            }
            REQUEST_FREE(tr);
            RESULT_FREE(r);
        }
        goto L_8888;
    }

    cmtt.nttm = nttmsv;
    if (lmodel) {
        float zero = 0.0;
        all_requested = phases_contains_all();
        iaspmodel(cmtt.ttdep / depth_units, &zero, 1.0, 360, nerr);
        goto L_7777;
    }

    /* if there is no alphanumeric data file, quit here.  maf 960829 */
    if (ndflin <= 0) {
        setmsg("WARNING", 5121);
        outmsg();
        goto L_8888;
    }

    files = wildfl(kmdfm.krddir, MCPFN + 1, list, &lexpnd);
    if (cmdfm.lechof && lexpnd) {
        setmsg("OUTPUT", 0);
        ic1 = 0;
        for (i = 0; i < string_list_length(files); i++) {
            file = string_list_get(files, i);
            apcmsg2(file, strlen(file) + 1);
        }
        wrtmsg(MUNOUT);
    }

    if (!lmore)
        cmtt.nttm = 0;

    /* - Main loop on each input file: */

    for (i = 0; i < string_list_length(files); i++) {
        file = string_list_get(files, i);
        /* -- Open input alphanumeric data file. */
        zopens(&nun, file, strlen(file), nerr);

        if (*nerr != 0)
            goto L_8888;

        /* If it's a TauP file, handle it separately. */
        if (ltaup) {
            readtaup(nun, &numych, nerr);
            if (*nerr)
                goto L_9000;
            nphaseNames = numych;
            goto L_5000;
        }

        /* -- Read first card.
         * --- If is a description card, decode it into PHASE information
         * --- Otherwise, backspace input file. */
        strscpy(kcont, kmdfm.kdcont, 8);
        nc = indexb(kmdfm.kdform, MCMSG + 1);
        if (kmdfm.kdform[0] == '(' && kmdfm.kdform[nc - 1] == ')') {
            fstrncpy(kform, 8, kmdfm.kdform, min(nc, 8));
        } else {
            fstrncpy(kform, 8, "(", 1);
            fstrncpy(kform + 1, 8 - 1, kmdfm.kdform, min(nc, 6));
            fstrncpy(kform + 1 + min(nc, 6), 8 - 1 - min(nc, 6), ")", 1);
        }
        lfree = cmdfm.ldfree;

        if (fgetsp(kcard, MCMSG + 1, nun) == NULL)
            goto L_9000;
        if (kcard[(numsave = strlen(kcard) - 1)] == '\n')
            kcard[numsave] = ' ';

        nc = indexb(kcard, MCMSG + 1);
        ic = 0;
        upcase(kcard, nc, kcard, MCMSG + 1);
        poptok(kcard, nc, &ic, &ic1, &ic2, &itype);
        lbcksp = TRUE;
        if (memcmp(kcard + ic1 - 1, "PHASE", 5) == 0) {
            jdx = 1;
            poptok(kcard, nc, &ic, &ic1, &ic2, &itype);
            while (!(itype == 0 || (jdx + cmtt.nttm > MXTT))) {
                fstrncpy(kmtt.kttnm[jdx + cmtt.nttm - 1], 5, kcard + ic1 - 1,
                         min(ic2, MCMSG) - ic1 + 1);
                jdx++;
                poptok(kcard, nc, &ic, &ic1, &ic2, &itype);
            }                   /* end while */
        } /* end if( memcmp(kcard+ic1 - 1,"PHASE",5) == 0 ) */
        else if (lbcksp) {
            backspace(nun, 1L);
        }

        /* -- Skip over header lines */
        for (idx = 1; idx <= cmtt.nhlines; idx++) {     /* nhlines is now global. maf 970808 */
            if (fgetsp(kcard, MCMSG + 1, nun) == NULL) {
                if (feof(nun))
                    goto L_5000;
                goto L_9000;
            }                   /* end if */
            if (kcard[(numsave = strlen(kcard) - 1)] == '\n')
                kcard[numsave] = ' ';
        }                       /* end for */

        /* -- Determine number of entries per card if formatted option. */
        if (!lfree)
            detnum(kform, 9, &nentry);

        /* -- Decode content information. */
        decont(kcont, 9, MXTT, &numch, &numxch, &numych, iopch, &ltoend, nerr);
        if (*nerr != 0)
            goto L_8888;

        /* -- Prime it to read in first card to see how many entries are really there */

        if (fgetsp(kcard, MCMSG + 1, nun) == NULL) {
            if (feof(nun))
                goto L_5000;
            goto L_9000;
        }
        if (kcard[(numsave = strlen(kcard) - 1)] == '\n')
            kcard[numsave] = ' ';

        /* --- Convert card to list of floating point values.
         *     Each card is in either free field or formatted. */
        if (lfree) {
            cnvfre(kcard, MCMSG + 1, MENTRY, &nentry, fentry, iopch, kalpha, 21, 1, nerr);      /* add 1 before nerr. maf 970129 */
        } else {
            cnvfmt(kcard, MCMSG + 1, kform, 9, nentry, fentry, nerr);
        }

        /* -- Loop on each line in text file.
         * --- Say something descriptive about data problems and get out. */
        if (*nerr != 0) {
            setmsg("ERROR", *nerr);
            reperr(*nerr);
            proerr(nerr);
            goto L_8888;
        }

        /* --- Redetermine how many y channels there really are */
        for (idx = 1; idx <= nentry; idx++) {
            if (Iopch[idx] > 0)
                numych = Iopch[idx];
        }

        /* --- Allocate memory block for X channel */
        nblksz = MBLKSZ;
        s->h->npts = 0;
        if (numxch == 1) {
            tx = (float *) malloc(sizeof(float) * nblksz);
        } else if (numxch > 1) {
            *nerr = 1361;
            setmsg("ERROR", *nerr);
            apcmsg("Can only have one X channel per file.", 38);
        }

        /* -- Allocate memory blocks for y channel(s). */
        if (numych >= 1) {
            for (jdx = 1; jdx <= numych; jdx++) {
                Nttpt[jdx + cmtt.nttm] = 0;
                if (numxch == 1) {      /* case of one X channel.  maf 970808 */
                    ttx[jdx + cmtt.nttm] = tx;
                    Ltteven[jdx + cmtt.nttm] = FALSE;
                } else {        /* case of no X channels.  maf 970808 */
                    Ltteven[jdx + cmtt.nttm] = TRUE;
                    Xttfirst[jdx + cmtt.nttm] = 0.0;
                    Xttdel[jdx + cmtt.nttm] = 1.0 * ttscale;
                }
                tty[jdx + cmtt.nttm] = (float *) malloc(sizeof(float) * nblksz);

            }                   /* end for */
        } /* end if ( numych >= 1 ) */
        else {
            *nerr = 1362;
            setmsg("ERROR", *nerr);
        }

        /* --- Say something descriptive about data problems and get out. */
      L_4000:
        if (*nerr != 0) {
            setmsg("ERROR", *nerr);
            reperr(*nerr);
            proerr(nerr);
            goto L_8888;
        }

        /* --- Fill in the channels, according to the the content vector. */

        /* This block had been changed in 96, but has now been largely restored to
           what it was in xtraveltime.c.orig.  maf 970808 */
        s->h->npts = s->h->npts + 1;
        for (jen = 1; jen <= nentry; jen++) {
            jch = Iopch[jen];
            if (jch >= 0) {
                if (s->h->npts > nblksz) {
                    /* --- This block is filled to capacity, release all blocks associated 
                     *     with the current model */
                    nblksz2 = 2 * nblksz;
                    /* --- Reallocate for x values */
                    if (!Ltteven[cmtt.nttm + 1]) {
                        {
                            float *tmp;
                            tmp =
                                (float *) realloc(ttx[cmtt.nttm + 1],
                                                  sizeof(float) * nblksz2);
                            if (tmp) {
                                ttx[cmtt.nttm + 1] = tmp;
                            } else {
                                fprintf(stderr,
                                        "error reallocating block for ttx\n");
                            }
                            if (*nerr != 0)
                                goto L_8888;
                        }
                    }
                    /* end if( !Ltteven[cmtt.nttm + 1] ) */
                    /* --- Reallocate for all y values */
                    for (idx = 1; idx <= numych; idx++) {
                        {
                            float *tmp;
                            tmp =
                                (float *) realloc(tty[cmtt.nttm + 1],
                                                  sizeof(float) * nblksz2);
                            if (tmp) {
                                tty[cmtt.nttm + 1] = tmp;
                            } else {
                                fprintf(stderr,
                                        "error reallocating block for tty\n");
                            }
                        }
                    }           /* end for */
                    nblksz = nblksz2;
                }               /* end if ( s->h->npts > nblksz ) */
                if (jch == 0)
                    ttx[cmtt.nttm + 1][s->h->npts - 1] = Fentry[jen] * ttscale;
                else {
                    tty[cmtt.nttm + jch][s->h->npts - 1] = Fentry[jen];
                    Nttpt[cmtt.nttm + jch] = s->h->npts;
                }
            }                   /* end if ( jch >= 0 ) */
        }                       /* end for ( jen ) */

        /* -- Read in next card. */

        if (fgetsp(kcard, MCMSG + 1, nun) == NULL) {
            if (feof(nun))
                goto L_5000;
            goto L_9000;
        }
        if (kcard[(numsave = strlen(kcard) - 1)] == '\n')
            kcard[numsave] = ' ';

        /* --- Convert card to list of floating point values.
         *     Each card is in either free field or formatted. */
        if (lfree) {
            cnvfre(kcard, MCMSG + 1, MENTRY, &nentry, fentry, iopch, kalpha, 21, 1, nerr);      /* add 1 before nerr. maf 970129 */
        } else {
            cnvfmt(kcard, MCMSG + 1, kform, 9, nentry, fentry, nerr);
        }
        /* --- Loop on each card in input file. */
        goto L_4000;

      L_5000:                  /* -- Come to here on end-of-file. */

        /* -- Close input file. */
        zcloses(&nun, nerr);
        if (*nerr != 0)
            goto L_8888;
        nun = NULL;

        /* -- Update current number of travel time curves. */
        cmtt.nttm = cmtt.nttm + numych;

    }

    /* - Check again for a non-null DFL. */

    if (cmtt.nttm <= 0) {
        *nerr = 1301;
        setmsg("ERROR", *nerr);
    }

  L_7777:
    /* If a blackboard variable was requested, set it here. maf 970514 */
    if (lbb) {
        int n;
        float tt[MAX_PHASES], dtdd[MAX_PHASES], dtdh[MAX_PHASES],
            dddp[MAX_PHASES];
        char names[MAX_PHASES][9];

        if (!(s = sacget(fileNumber - 1, FALSE, nerr))) {
            goto L_9000;
        }
        //getfil ( fileNumber , FALSE, &n1, &n1, &n1, nerr );

        trtm(s->h->gcarc, MAX_PHASES, &n, tt, dtdd, dtdh, dddp, (char *) names,
             9);
        sprintf(kValue, "%.4f", tt[0]);
        setbbv(bbName, kValue, nerr, strlen(bbName), strlen(kValue));
    } else {
        for (jdfl = 1; jdfl <= saclen(); jdfl++) {
            if (!(s = sacget(jdfl - 1, FALSE, nerr))) {
                goto L_9000;
            }
            //getfil ( jdfl , FALSE , &n1, &n1, &n1, nerr ) ;
            {
                int i, j, set, k;
                int p;
                int n;
                float tt[MAX_PHASES], dtdd[MAX_PHASES], dtdh[MAX_PHASES],
                    dddp[MAX_PHASES];
                char names[MAX_PHASES][9];
                char picks_set[MAX_PHASES][128];
                int nset = 0;
                /* Find all phases at this distance range */
                trtm(s->h->gcarc, MAX_PHASES, &n, tt, dtdd, dtdh, dddp,
                     (char *) names, 9);
                k = nPickStart;
                for (i = 0; i < n; i++) {
                    sac_truncate(names[i]);
                }
                if(all_requested) {
                    // Phases from trtm() are sorted by time, first phase occurance should be the earliest
                    for(i = 0; i < n; i++) {
                        if(phase_is_set(names[i], picks_set, nset)) {
                            continue;
                        }
                        k = set_traveltime(s, k, names[i], tt[i], lpicks, verbose, onrecord);
                        nset = phase_set(names[i], picks_set, nset);
                    }
                } else {

                    /* Specificed phases */
                    for (j = 0; j < cmtt.nphases; j++) {
                        set = FALSE;
                        /* Possible phases */
                        p = -1;
                        if(phase_is_set(kmtt.kphases[j], picks_set, nset)) {
                            continue;
                        }
                        for (i = 0; i < n; i++) {
                            if (strcmp(names[i], kmtt.kphases[j]) == 0) {   /* Requested Phase =? Possible Phase */
                                if (p < 0 || tt[i] < tt[p]) {       /* Set if phase is the minimum traveltime */
                                    p = i;
                                    set = TRUE;
                                }
                            }
                        }
                        if (set == TRUE) {
                            k = set_traveltime(s, k, names[p], tt[p], lpicks, verbose, onrecord);
                        } else {
                            if (verbose) {
                                printf("traveltime: error finding phase %-8s\n", kmtt.kphases[j]);
                            }
                        }
                    }
                }
            }

        }
    }

  L_8888:
    if(all_requested) {
        strlcpy(kmtt.kphases[0], "all", PHASE_NAME_LENGTH-1);
        cmtt.nphases = 1;
    }
    /* - Return. (Try to close alphanumeric data file just to be sure.) */

    if (nun)
        zcloses(&nun, &ncerr);

    return;

  L_9000:
    *nerr = 114;
    error(*nerr, "%s", (file) ? file : "No file");
    goto L_8888;

}                               /* end of function */

void
readtaup(FILE * taupfile, int *ncurves, int *nerr) {
    /* Declare local variables. */
    char buffer[121], *bPtr, *phPtr;
    char **phaseNames = NULL, **temp;
    int idx, jdx;

    /* Find first phase line. */
    do {
        bPtr = fgetsp(buffer, 120, taupfile);
        if (!bPtr) {
            *nerr = 5125;
            goto L_ERROR;
        }
    } while (*bPtr != '>');

    /* Loop between phases to count the number of datapoints. */
    for (jdx = 0; bPtr && *bPtr == '>' && jdx + cmtt.nttm < MXTT - 1; jdx++) {
        /* allocate phaseName */
        *ncurves = jdx + 1;
        temp = (char **) realloc(phaseNames, (jdx + 1) * sizeof(char *));
        if (!temp) {
            *nerr = 301;
            goto L_ERROR;
        }
        phaseNames = temp;
        phaseNames[jdx] = (char *) calloc(26, sizeof(char));
        if (!phaseNames[jdx]) {
            *nerr = 301;
            goto L_ERROR;
        }

        /* Get Phase Name */
        for (bPtr += 2, phPtr = phaseNames[jdx]; *bPtr != ' '; bPtr++, phPtr++)
            *phPtr = *bPtr;
        *phPtr = '\0';

        /* count lines. */
        bPtr = fgetsp(buffer, 120, taupfile);
        for (cmtt.nttpt[jdx] = 0; bPtr && *bPtr != '>' && *bPtr != 'E';
             cmtt.nttpt[jdx]++) {
            bPtr = fgetsp(buffer, 120, taupfile);
        }

    }
    *ncurves = jdx;

    /* Go back to the beginning of the file. */
    rewind(taupfile);

    /* Prepare to read the data */
    do {
        bPtr = fgetsp(buffer, 120, taupfile);
        if (!bPtr) {
            *nerr = 5125;
            goto L_ERROR;
        }
    } while (*bPtr != '>');

    /* Now loop between phases to read the data. */
    for (jdx = 0; jdx < *ncurves; jdx++) {
        /* allocate space for the X (distance) and Y (time) data */
        tty[jdx] = (float *) malloc(sizeof(float) * cmtt.nttpt[jdx]);
        ttx[jdx] = (float *) malloc(sizeof(float) * cmtt.nttpt[jdx]);

        /* Loop between datapoints, read data, convert km to degrees */
        for (idx = 0; idx < cmtt.nttpt[jdx]; idx++) {
            /* read line of data */
            bPtr = fgetsp(buffer, 120, taupfile);

            /* read X, convert to km */
            ttx[jdx][idx] = atof(bPtr) * RKMPERDG;

            /* find and read Y */
            while (!isspace(*bPtr))
                bPtr++;
            tty[jdx][idx] = atof(bPtr);
        }
    }

  L_ERROR:
    if (*nerr) {
        setmsg("ERROR", *nerr);
        outmsg();
        if (phaseNames) {
            for (jdx = *ncurves - 1; jdx >= 0; jdx--)
                FREE(phaseNames[jdx]);
            free(phaseNames);
        }
        return;
    }

    kmtt.kphaseNames = phaseNames;
}

