
		/* PARAMETER translations */
#define	JBRN	100
#define	JBRNA	JBRN
#define	JBRNU	JBRN
#define	JOUT	2500
#define	JREC	(JTSM + JXSM)
#define	JSEG	30
#define	JSRC	150
#define	JTSM	350
#define	JTSM0	(JTSM + 1)
#define	JXSM	JBRN
		/* end of PARAMETER translations */

