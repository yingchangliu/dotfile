/** 
 * @file   wapf.c
 * 
 * @brief  Write a pick to a file
 * 
 */

#include <stdlib.h>
#include <string.h>

#include "amf.h"
#include "ucf.h"
#include "dfm.h"
#include "hdr.h"
#include "eam.h"
#include "bot.h"

#include "clf.h"

EAM_EXTERN

#define YD_HMS " %04d%03d %02d %02d %05.2f"

/** 
 * Write a pick to an alphanumeric pick file (APF)
 * 
 * @date   860319:  Added PTP option.
 * @date   810105:  Changed Ew.d formats to Gw.d.
 * @date   800829:  Added ability to write times as GMT or not.
 *                  Added ability to write either header info or filename.
 * @date   800505:  Original version.
 *
 */
void
wapf() {

    char kapfln[133];
    int j, nexday, npkmsc, npksec;
    char *tmp;
    sac *s;
    memset(&kapfln[0], 0, 133);

    /* - Each pick consists of a pick_id, event_id, station_id, component_id,
     *   and pick source (automatic, manual etc.), as well as the date, time,
     *   and amplitude of the pick itself. 
     *
     * - For certain picks, auxiliary information is also added to the card. 
     */
    if (!(s = sacget_current())) {
        return;
    }
    /* Get filename. */
    tmp = s->m->filename;
    /* - Each pick output line can contain 200 columns. */

    if (cmeam.lpfgmt) {
        inctim(s->h->nzhour, s->h->nzmin, s->h->nzsec, s->h->nzmsec,
               cmeam.pkseci, &cmeam.npkhr, &cmeam.npkmn, &npksec, &npkmsc,
               &nexday);
        cmeam.pksecs = tosecs(npksec, npkmsc);
        incdat(s->h->nzyear, s->h->nzjday, nexday, &cmeam.npkyr, &cmeam.npkjdy);
    }

    if (cmeam.lpfgmt && cmeam.lpfstd) {
        if ((strcmp(kmeam.kpkid, "MWF     ") == 0 ||
             strcmp(kmeam.kpkid, "WF      ") == 0) ||
            strcmp(kmeam.kpkid, "WAWF    ") == 0) {
            if (sprintf
                (kapfln,
                 "%16s%8s%7.2f%7.2f%4s" YD_HMS " %10.4g %1s %3s%c",
                 s->h->kevnm, s->h->kstnm, s->h->cmpaz, s->h->cmpinc,
                 kmeam.kpkid, cmeam.npkyr, cmeam.npkjdy, cmeam.npkhr,
                 cmeam.npkmn, cmeam.pksecs, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'B') < 0)
                goto L_8000;

            for (j = 2; j <= 5; j++) {
                if (sprintf(kapfln + 80 + ((j - 2) * 6), "%6.3f", Dtwf[j]) < 0)
                    goto L_8000;
            }
            if (sprintf
                (kapfln + 80 + (4 * 6), " %10.4g %10.4g\n", Awf[2], Awf[4])
                < 0)
                goto L_8000;
        } else if (strcmp(kmeam.kpkid, "PTP     ") == 0) {
            if (sprintf
                (kapfln,
                 "%16s%8s%7.2f%7.2f%4s" YD_HMS " %10.4g %1s %3s%c%6.3f%10.4g\n",
                 s->h->kevnm, s->h->kstnm, s->h->cmpaz, s->h->cmpinc,
                 kmeam.kpkid, cmeam.npkyr, cmeam.npkjdy, cmeam.npkhr,
                 cmeam.npkmn, cmeam.pksecs, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'B', Dtwf[4], Awf[4]) < 0)
                goto L_8000;
        } else {
            if (sprintf
                (kapfln,
                 "%16s%8s%7.2f%7.2f%4s" YD_HMS " %10.4g %1s %3s %c\n",
                 s->h->kevnm, s->h->kstnm, s->h->cmpaz, s->h->cmpinc,
                 kmeam.kpkid, cmeam.npkyr, cmeam.npkjdy, cmeam.npkhr,
                 cmeam.npkmn, cmeam.pksecs, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'B') < 0)
                goto L_8000;
        }
    } else if (cmeam.lpfgmt && !cmeam.lpfstd) {
        if ((strcmp(kmeam.kpkid, "MWF     ") == 0 ||
             strcmp(kmeam.kpkid, "WF      ") == 0) ||
            strcmp(kmeam.kpkid, "WAWF    ") == 0) {
            if (sprintf
                (kapfln, "%32s      %4s" YD_HMS " %10.4g %1s %3s%c", tmp,
                 kmeam.kpkid, cmeam.npkyr, cmeam.npkjdy, cmeam.npkhr,
                 cmeam.npkmn, cmeam.pksecs, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'C') < 0) {
                goto L_8000;
            }
            for (j = 2; j <= 5; j++) {
                if (sprintf(kapfln + 80 + ((j - 2) * 6), "%6.3f", Dtwf[j]) < 0)
                    goto L_8000;
            }
            if (sprintf
                (kapfln + 80 + (4 * 6), " %10.4g %10.4g\n", Awf[2], Awf[4])
                < 0)
                goto L_8000;
        } else if (strcmp(kmeam.kpkid, "PTP     ") == 0) {
            if (sprintf
                (kapfln,
                 "%32s      %4s" YD_HMS " %10.4g %1s %3s%c%6.3f%10.4g\n",
                 tmp, kmeam.kpkid, cmeam.npkyr, cmeam.npkjdy, cmeam.npkhr,
                 cmeam.npkmn, cmeam.pksecs, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'C', Dtwf[4], Awf[4]) < 0) {
                goto L_8000;
            }
        } else {
            if (sprintf
                (kapfln, "%32s      %4s" YD_HMS " %10.4g %1s %3s%c\n",
                 tmp, kmeam.kpkid, cmeam.npkyr, cmeam.npkjdy, cmeam.npkhr,
                 cmeam.npkmn, cmeam.pksecs, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'C') < 0) {
                goto L_8000;
            }
        }
    } else if (!cmeam.lpfgmt && cmeam.lpfstd) {
        if ((strcmp(kmeam.kpkid, "MWF     ") == 0 ||
             strcmp(kmeam.kpkid, "WF      ") == 0) ||
            strcmp(kmeam.kpkid, "WAWF    ") == 0) {
            if (sprintf
                (kapfln,
                 "%16s%8s%7.2f%7.2f%4s          %10.4g %10.4g %1s %3s%c",
                 s->h->kevnm, s->h->kstnm, s->h->cmpaz, s->h->cmpinc,
                 kmeam.kpkid, cmeam.pkseci, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'D') < 0)
                goto L_8000;

            for (j = 2; j <= 5; j++) {
                if (sprintf(kapfln + 80 + ((j - 2) * 6), "%6.3f", Dtwf[j]) < 0)
                    goto L_8000;
            }
            if (sprintf
                (kapfln + 80 + (4 * 6), " %10.4g %10.4g\n", Awf[2], Awf[4]) < 0)
                goto L_8000;
        } else if (strcmp(kmeam.kpkid, "PTP     ") == 0) {
            if (sprintf
                (kapfln,
                 "%16s%8s%7.2f%7.2f%4s          %10.4g %10.4g %1s %3s%c%6.3f%10.4g\n",
                 s->h->kevnm, s->h->kstnm, s->h->cmpaz, s->h->cmpinc,
                 kmeam.kpkid, cmeam.pkseci, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'D', Dtwf[4], Awf[4]) < 0)
                goto L_8000;
        } else {
            if (sprintf
                (kapfln,
                 "%16s%8s%7.2f%7.2f%4s          %10.4g %10.4g %1s %3s%c\n",
                 s->h->kevnm, s->h->kstnm, s->h->cmpaz, s->h->cmpinc,
                 kmeam.kpkid, cmeam.pkseci, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'D') < 0)
                goto L_8000;
        }
    } else {
        if ((strcmp(kmeam.kpkid, "MWF     ") == 0 ||
             strcmp(kmeam.kpkid, "WF      ") == 0) ||
            strcmp(kmeam.kpkid, "WAWF    ") == 0) {
            if (sprintf
                (kapfln, "%32s      %4s          %10.4g %10.4g %1s %3s%c", tmp,
                 kmeam.kpkid, cmeam.pkseci, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'E') < 0) {
                goto L_8000;
            }
            for (j = 2; j <= 5; j++) {
                if (sprintf(kapfln + 80 + ((j - 2) * 6), "%6.3f", Dtwf[j]) < 0)
                    goto L_8000;
            }
            if (sprintf
                (kapfln + 80 + (4 * 6), " %10.4g %10.4g\n", Awf[2], Awf[4]) < 0)
                goto L_8000;
        } else if (strcmp(kmeam.kpkid, "PTP     ") == 0) {
            if (sprintf
                (kapfln,
                 "%32s      %4s          %10.4g %10.4g %1s %3s%c%6.3f%10.4g\n",
                 tmp, kmeam.kpkid, cmeam.pkseci, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'E', Dtwf[4], Awf[4]) < 0) {
                goto L_8000;
            }
        } else {
            if (sprintf
                (kapfln, "%32s      %4s          %10.4g %10.4g %1s %3s%c\n",
                 tmp, kmeam.kpkid, cmeam.pkseci, cmeam.pkampl, kmeam.kpksrc,
                 kmeam.kpkrid, 'E') < 0) {
                goto L_8000;
            }
        }
    }

    /* - Write encoded character string to APF. */

  L_8000:
    fprintf(cmeam.napfun, "%s\n", kapfln);

    return;

}                               /* end of function */
