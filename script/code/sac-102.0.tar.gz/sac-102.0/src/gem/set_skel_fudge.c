
#include "gem.h"

GEM_EXTERN

void
set_skeleton_fudge(float fudge) {
    cmgem.skdevfudge = fudge;
}
