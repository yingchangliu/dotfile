/** 
 * @file   inidfm.c
 * 
 * @brief  Initialize the Data File Management Block
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "co.h"
#include "dfm.h"
#include "clf.h"
#include "bool.h"


#include "cssListOps/cssArchitecture.h"

#include "co.h"
#include "bot.h"
#include "dff.h"
#include "debug.h"

struct t_cmdfm cmdfm;
struct t_kmdfm kmdfm;

void
dfm_free() {
    int i;
    if (kmdfm.kauthors) {
        for (i = 0; i < cmdfm.iauthors; i++) {
            FREE(kmdfm.kauthors[i]);
        }
        FREE(kmdfm.kauthors);
    }
}

/** 
 * Variable initialization of the Data File Management Block
 * 
 * @date   981102:  Remove ncdscnt.  maf
 * @date   970409:  Allow readcss to get picks from .arrival file.  maf
 * @date   970403:  Allow broad selection on channel.  maf
 * @date   961216:  Changed gain variables to station variables.  rcss is
 *             filtering on station rather than gain.  maf
 * @date   961111:  Added cmdfm.lshift to tell whether rcss should shift
 *             the origin time to zero.  maf
 * @date   920515:  Added initialization of ndsflcnt and nflncds to zero.
 * @date   920410:  Removed initialization of ndsflcnt to 1. Previously
 *             used to avoid counting all the file in getdsflcnt.
 * @date   910828:  Added initialization of ncdscnt and ncdsndx array.
 * @date   910812:  Added initialization of multiple data-set stuff.
 * @date   870915:  Deleted fmtsoc, fmtsac, iinmem, etc. variables.
 * @date   870217:  Added initialization of READALPHA command.
 * @date   860917:  Deleted KZDFL.  Added KSUFFX.
 * @date   850801:  Deleted SOCKITTOME format.
 * @date   850415:  Changes due to restructuring of DFM common block.
 * @date   831020:  Added initialization of SYNCH command.
 * @date   820806:  Added initialization of LOVRRQ.
 * @date   810414:  Original version.
 *
 */
void
inidfm() {

    int jdx;
    int nerr;

    inihdr();

    dfm_free();

    cmdfm.lcut = FALSE;

    strcpy(kmdfm.kpick[0], "N       ");
    strcpy(kmdfm.kpick[1], "Z       ");
    strcpy(kmdfm.kpick[2], "G       ");
    strcpy(kmdfm.kpick[3], "B       ");
    strcpy(kmdfm.kpick[4], "E       ");
    strcpy(kmdfm.kpick[5], "O       ");
    strcpy(kmdfm.kpick[6], "A       ");
    strcpy(kmdfm.kpick[7], "T0      ");
    strcpy(kmdfm.kpick[8], "T1      ");
    strcpy(kmdfm.kpick[9], "T2      ");
    strcpy(kmdfm.kpick[10], "T3      ");
    strcpy(kmdfm.kpick[11], "T4      ");
    strcpy(kmdfm.kpick[12], "T5      ");
    strcpy(kmdfm.kpick[13], "T6      ");
    strcpy(kmdfm.kpick[14], "T7      ");
    strcpy(kmdfm.kpick[15], "T8      ");
    strcpy(kmdfm.kpick[16], "T9      ");
    strcpy(kmdfm.kpick[17], "F       ");

    cmdfm.ipckn = 1;
    cmdfm.ipckz = 2;
    cmdfm.ipckg = 3;
    cmdfm.ipckb = 4;
    cmdfm.ipcke = 5;
    cmdfm.ipcko = 6;
    cmdfm.ipcka = 7;
    cmdfm.ipckt0 = 8;
    cmdfm.ipckt1 = 9;
    cmdfm.ipckt2 = 10;
    cmdfm.ipckt3 = 11;
    cmdfm.ipckt4 = 12;
    cmdfm.ipckt5 = 13;
    cmdfm.ipckt6 = 14;
    cmdfm.ipckt7 = 15;
    cmdfm.ipckt8 = 16;
    cmdfm.ipckt9 = 17;
    cmdfm.ipckf = 18;

    cmdfm.ipckhd[0] = 0; // N
    cmdfm.ipckhd[1] = 0; // Z
    cmdfm.ipckhd[2] = 0; // G
    cmdfm.ipckhd[3] = 6; // B
    cmdfm.ipckhd[4] = 7; // E
    cmdfm.ipckhd[5] = 8; // O
    cmdfm.ipckhd[6] = 9; // A
    for (jdx = 7; jdx <= 17; jdx++) { // T0-T9
        cmdfm.ipckhd[jdx] = jdx + 3 + 1;
    }

    fstrncpy(kmdfm.krddir, MCPFN, " ", 1);
    memset(kmdfm.kwrdir, 0, MCPFN);
    fstrncpy(kmdfm.kdirnm, MCPFN, "FIRST_TIME", 10);
    cmdfm.ncdir = indexb(kmdfm.kdirnm, MCPFN + 1);
    cmdfm.lechof = TRUE;

    fstrncpy(kmdfm.krdcssdir, MCPFN, " ", 1);
    kmdfm.lstation = FALSE;
    kmdfm.lchannel = FALSE;
    kmdfm.lbandw = FALSE;
    kmdfm.lorient = FALSE;
    strcpy(kmdfm.kstation, "*     ");
    strcpy(kmdfm.kchannel, "*       ");
    strcpy(kmdfm.kbandw, "*       ");
    strcpy(kmdfm.korient, "*       ");

    cmdfm.lovrrq = FALSE;

    strcpy(kmdfm.kcuter[0], "FATAL   ");
    strcpy(kmdfm.kcuter[1], "USEBE   ");
    strcpy(kmdfm.kcuter[2], "FILLZ   ");
    cmdfm.icuter = 2;
    cmdfm.nrwfmt = 2;
    strcpy(kmdfm.krwfmt[0], "SAC     ");
    strcpy(kmdfm.krwfmt[1], "ALPHA   ");
    cmdfm.iwfmt = 1;
    //Icfmt[1] = 1;
    //Icfmt[2] = 1;
    strcpy(kmdfm.kcfmt[0], "%#15.7g");
    strcpy(kmdfm.kcfmt[1], "%#15.7g");
    fstrncpy(kmdfm.kcfile[0], MCPFN, "in.saf", 6);
    fstrncpy(kmdfm.kcfile[1], MCPFN, "out.saf", 7);

    strcpy(kmdfm.kecbdf, "WARNING ");
    strcpy(kmdfm.kecmem, "SAVE    ");

    /* - SYNCH command. */
    cmdfm.lround = FALSE;

    /* - READALPHA command. */
    cmdfm.ldfree = TRUE;
    fstrncpy(kmdfm.kdform, MCMSG, "(5G15.7)", 8);
    fstrncpy(kmdfm.kdcont, MCMSG, "Y.", 2);

    /* - DATAGEN command. */
    strcpy(kmdfm.kdgsub[0], "LOCAL   ");
    strcpy(kmdfm.kdgsub[1], "REGIONAL");
    strcpy(kmdfm.kdgsub[2], "TELESEIS");
    cmdfm.idgsub = 1;
    fstrncpy(kmdfm.kdgfil, MCMSG, " cdv.z", 6);
    cmdfm.ndgfil = 1;

    /* by default rcss shifts orogin time to zero.  */
    cmdfm.lshift = TRUE;
    /* by default, don't calibrate */
    cmdfm.lscale = FALSE;

    /* by default choose mag from algorithm. */
    cmdfm.nMagSpec = Any;

    /* The following added to facilitate rcss reading picks from
     *   the .arrival css file. 
     */
    cmdfm.lpref = FALSE;
    cmdfm.iauthors = 0;
    kmdfm.kauthors = NULL;

    /* get name of pick prefrences file */

    zbasename(kmdfm.kprefsFileName, MCPFN + 1);
    if (strlen(kmdfm.kprefsFileName) == 0) {
        fprintf(stderr, "ERROR: Environmental variable SACAUX not defined.\n");
        exit(1);
    }

    /* append the name of the prefs file. */
    crname(kmdfm.kprefsFileName, MCPFN + 1, KDIRDL, "csspickprefs",
           strlen("csspickprefs") + 1, &nerr);
    rstrip(kmdfm.kprefsFileName);
    getprefs(TRUE, TRUE);

    /* SORT command */
    cmdfm.nSortOrder = 0;
    for (jdx = 0; jdx < MAXSORTFIELDS; jdx++) {
        kmdfm.ksort[jdx][0] = '\0';
        cmdfm.idirection[jdx] = Ascending;
    }

    /* added for array option in readcss */
    cmdfm.larray = FALSE;

    /* read and write ascii by default */
    cmdfm.lrascii = TRUE;
    cmdfm.lwascii = TRUE;

    /* COMMIT and ROLLBACK options. */
    cmdfm.icomORroll = COMMIT;

    /* BINARY or ASCII options */
    strcpy(kmdfm.kbinORasc[BINARY], "BINARY  ");
    strcpy(kmdfm.kbinORasc[ASCII], "ASCII   ");

    /* COMMIT option on deletechannel */
    cmdfm.lcommit = FALSE;

    /* rdsegy */
    cmdfm.iztype = IB;

    /* writetable  */
    cmdfm.liftype = FALSE;
    cmdfm.lheader = FALSE;

    /* Fix data transfer from SAC buffers to CSS buffers. */
    cmdfm.ltrust = TRUE;
    cmdfm.nreadflag = RDB;
    cmdfm.lread = FALSE;
    cmdfm.nfilesFirst = 0;

    /* TRUE has GSE write CM6 data instead of integer. */
    cmdfm.lcm6 = FALSE;

}
